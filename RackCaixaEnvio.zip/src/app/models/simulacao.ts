export interface Simulacao{
    valorDesejado: number;
    prazo: number;
}