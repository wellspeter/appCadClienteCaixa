export interface elementoTabSimulacao {
    numero: number;
    valorAmortizacao: number;
    valorJuros: number;
    valorPrestacao: number;
  }