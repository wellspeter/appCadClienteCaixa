import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Simulacao } from '../models/simulacao';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SimuladorService {

  private API_DES = 'https://apphackaixades.azurewebsites.net/api'

  constructor(private http: HttpClient) { }

  public calcular(simulacao:Simulacao):Observable<any>{
    return this.http.post(this.API_DES + '/Simulacao', simulacao);
  }

}
