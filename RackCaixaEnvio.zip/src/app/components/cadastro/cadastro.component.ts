import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { SimuladorService } from 'src/app/services/simulador.service';
import { FormBuilder, FormControl, FormGroup, FormGroupDirective, NgForm, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { Router } from '@angular/router';
import { Simulacao } from 'src/app/models/simulacao';
import { elementoTabSimulacao } from 'src/app/models/elementoTabSimulacao';
import { MatTableDataSource } from '@angular/material/table';



export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-cadastro',
  templateUrl: './cadastro.component.html',
  styleUrls: ['./cadastro.component.css']
})
export class CadastroComponent implements OnInit {

  simulacaoForm!: FormGroup;
  displayedColumns = ['numero', 'valorAmortizacao', 'valorJuros', 'valorPrestacao'];
  dataSourcePrice = [];
  dataSourceSAC  = [];
  codigoProduto!: number;
  descricaoProduto!: number;
  taxaJuros!: number;
  retorno:any;



  constructor(
    private simuladorService: SimuladorService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.simulacaoForm = new FormGroup({
      valor: new FormControl('', [Validators.required]),
      prazo: new FormControl('', [Validators.required])
    }); 
  }

  get valor(){
    return this.simulacaoForm.get('valor')?.value!;
  }

  get prazo(){
    return this.simulacaoForm.get('prazo')?.value!;
  }

  calcular() {

    if(this.simulacaoForm.invalid){
      return
    }

    var simulacao: Simulacao={
      valorDesejado: this.valor,
      prazo: this.prazo
    }

    this.simuladorService.calcular(simulacao).subscribe(response => {
      this.retorno = response;
      this.codigoProduto = this.retorno.codigoProduto;
      this.descricaoProduto = this.retorno.descricaoProduto;
      this.taxaJuros = this.retorno.taxaJuros;

      this.retorno.resultadoSimulacao.forEach((element: { tipo: string; parcelas: never[]; }) => {
        if(element.tipo == "PRICE"){
          this.dataSourcePrice = element.parcelas
        }
        if(element.tipo == "SAC"){
          this.dataSourceSAC = element.parcelas
        }
      });

    }, error => {
      alert("Erro: " +error.status )
    });
  }

  salvar():void{
    this.router.navigate(['/confirmacao']);
    //this.clienteService.cadastra(this.clientepf)
  }

  submitPessoaFisica(){
    /* if(this.clientepfForm.invalid){
      return
    } */
    
    console.log("foi o  cadastro de pessoa fisica")
  }
}